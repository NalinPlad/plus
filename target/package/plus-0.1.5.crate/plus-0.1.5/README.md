# rustcalc

The only CLI calculator you'll ever need
